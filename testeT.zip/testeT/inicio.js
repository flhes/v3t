document.getElementById('inicio').addEventListener('click', function() {
    window.history.back();
});
